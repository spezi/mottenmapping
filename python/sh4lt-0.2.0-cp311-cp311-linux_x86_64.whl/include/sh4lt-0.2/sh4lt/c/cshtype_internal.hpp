/*
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 */

#ifndef _SH4LT_C_SHTYPE_INTERNAL_H_
#define _SH4LT_C_SHTYPE_INTERNAL_H_

#include "../logger/logger.hpp"
#include "../shtype/shtype.hpp"
#include "./clogger.h"

namespace sh4lt {

struct CShType {
  CShType(const char* media, const char* label, const char* group_label);
  CShType(ShType shtype);
  ShType shtype_;
};

}  // namespace sh4lt

#endif
