/*
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 */

#ifndef SH4LT_C_FOLLOWER_H_
#define SH4LT_C_FOLLOWER_H_

#include <stdlib.h>

#include "./clogger.h"
#include "./time-info.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef void* Sh4ltFollower;

/**
 * Construct of a Sh4ltFollower that read a sh4lt, and handle
 * connection/disconnection of the writer.
 * Information and data are provided asynchronously by the Follower though callbacks.
 *
 * \param   path                     Sh4lt path to follow
 * \param   on_data_cb               Callback to be triggered when a frame is published
 * \param   on_server_connected      Callback to be triggered when the follower
 *                                   connected with the sh4lt writer
 * \param   on_server_disconnected   Callback to be triggered when the follower
 *                                   disconnected from the sh4lt writer
 * \param   user_data                Pointer to be given back
 *                                   when the callback is triggered
 * \param   log                      Log object where to write
 *                                   internal logs
 *
 * \return  Created Sh4ltFollower
 */
Sh4ltFollower sh4lt_make_follower(
    const char* path,
    void (*on_data_cb)(void* user_data, void* data, size_t size, const sh4lt_time_info_t*),
    void (*on_server_connected)(void* user_data, const char* type_descr),
    void (*on_server_disconnected)(void* user_data),
    void* user_data,
    Sh4ltLogger log);

/**
 * Enable/disable monitor relaunch when writer has disconnected. When a follower is created,
 * monitor relaunch is enabled.
 *
 * \param follower The follower to apply
 * \param monitor Set to true if monitor must be relaunched, false otherwise.
 */
void sh4lt_set_monitor_relaunch(Sh4ltFollower follower, int relaunch);

/**
 * Delete a Sh4ltFollower and release associated ressources
 *
 * \param follower The follower to apply
 */
void sh4lt_delete_follower(Sh4ltFollower follower);

#ifdef __cplusplus
}
#endif

#endif
