/*
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 */

#ifndef SH4LT_DATA_PRINTER_H_
#define SH4LT_DATA_PRINTER_H_

#include <functional>
#include <optional>
#include <string>

namespace sh4lt::utils {

using data_printer_t =
    std::function<std::string(const void* data, std::size_t size, std::size_t num_val_to_print)>;

/**
 * Make a print function that provide a formated string containing of the first `num_val_to_print`
 * value of a Sh4lt buffer.
 *
 * Here are the supported formats :
 *  'x'   for hexadecimal (default)
 *  'c'   for char
 *  'f'   for 32 bits float
 *  'd'   for 64 bits float
 *  'i8'  for 8 bits integer
 *  'i16' for 16 bits integer
 *  'i32' for 32 bits integer
 *  'i64' for 64 bits integer
 *  'ui8'  for unsigned 8 bits integer
 *  'ui16' for unsigned 16 bits integer
 *  'ui32' for unsigned 32 bits integer
 *  'ui64' for unsigned 64 bits integer
 *
 * \param value_format printing format for values in buffer.
 * \param separator separator between values during print.
 * \param precision precision for float and int (between 1 and 16).
 * \param min_width minimum width of the printed value. 0 is disabling min width. Width does not
 *        apply for hexadecimal and char formats.
 *
 * \return the print function that can be used in a `on_data` Sh4lt callback. It is wrapper in a
 * optional and must be tested before use in order to validate the format asked.
 *
 **/
std::optional<data_printer_t> make_data_printer_fun(std::string value_format = "x",
                                                    std::string separator = " ",
                                                    size_t precision = 3,
                                                    size_t min_width = 0);

}  // namespace sh4lt::utils
#endif
