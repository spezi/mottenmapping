sh4lt 0.0.4 (2024-02-07)
---------------------------


sh4lt 0.2.0 (2025-11-25)
---------------------------

Breaking changes:

* increase shtype max size from 4096 to 65536
* add speed in timeinfo structure

The port from sh4lt 0.1 to 0.2 requires to inform Sh4lt writers (`Writer` class) the speed when writing. An extra argument, `speed` (float), is required for the following methods:

* `copy_to_shm` now takes `float speed` as last argument. Normal speed is 1.0, and set as the default argument value for C++ and python. A speed of 2.0 is twice faster and a speed of 0.5 is twice slower. 0.0 is for offline, an negative values indicated a reversed playing. 
* same applies to `notify_clients`.

sh4lt 0.1.30 (2025-11-07)
---------------------------

* shflow -n actually display ONLY sh4lt data
* fix shtype set_prop do not update prop if already exists
* fix data_printer with 0-sized sh4lt buffer
* fix shflow option with -m 0
* fix data print for small buffers
sh4lt 0.1.28 (2025-10-08)
---------------------------

* add -Wno-error=restrict flag during compilation to fix gcc12 issue with char_traits.h
* update cmake minimum version
sh4lt 0.1.26 (2025-09-04)
---------------------------

* fix connected statistic

sh4lt 0.1.24 (2025-09-04)
---------------------------

* fix shflow does not accept any formating

sh4lt 0.1.22 (2025-09-04)
---------------------------

* add more data types in shflow
* add data entry to follower stat
* add data and printing configuration in python wrapper

sh4lt 0.1.20 (2025-03-31)
---------------------------

* add shlist command
* add option for int and float precision in shflow
* add separator option in shflow

sh4lt 0.1.18 (2024-10-31)
---------------------------

* make shlinew wait more after writer creation before first write

sh4lt 0.1.16 (2024-10-08)
---------------------------

New features:
* add set_monitor_relaunch method in follower
* add wait_readers_for method in writer
* add user description to shtype

Improvements after stress testing:
* use threaded wrapper instead of "raw" std::future
* fix sometimes overlap of monitors in follower
* deadlock fixes

Bug fixes:
* fix shlinew missing first buffer
* fix sometimes high cpu usage when monitoring not enabled Sh4lt
* fix safe bool log msg method
* fix has_msg method in safe bool log

sh4lt 0.1.14 (2024-10-07)
---------------------------

New features:
* add user description to shtype
* add set_monitor_relaunch method in follower
* add wait_readers_for method in writer

Improvements  stress testing: 
* use threaded wrapper instead of "raw" std::future
* fix sometimes overlap of monitors in follower
* several deadlock fixes
* shlinew wait readers to finish before exit
* wait server disconneted in check-writer-follower.py

Bug fixes:
* fix shlinew missing first buffer
* fix sometimes high cpu usage when monitoring not enabled Sh4lt
* fix safe bool log msg method
* fix has_msg method in safe bool log
sh4lt 0.1.12 (2024-09-04)
---------------------------

* Use back console logger in python wrapper
* Follower stat provides stats only if a shtype has been received
* Do not force call to on_connect during construction in unix socket client
* Add protected method to BoolLog
sh4lt 0.1.10 (2024-08-08)
---------------------------

* fix writer fails when initialized with size 0
* make html directory installation optional

sh4lt 0.1.8 (2024-08-03)
---------------------------

* Fix build failures on macOS / clang / unity build

sh4lt 0.1.6 (2024-08-02)
---------------------------

* ignore stringop-overflow warning for release build package with ubuntu 22.04
* fix build issue with time.cpp

sh4lt 0.1.4 (2024-08-01)
---------------------------

* build with clang18 and gcc14
* add monitor, dir-watcher and follower-stat
* fix python "set debug" method, renamed into "set_debug"
* add py-logger for python wrapper
* use same version number for sh4lt and python module
* install python module in . when scikit is used for building
* update README.md with pip installation instructions
* apply new version number in sh4lt python module version when the release script is used

sh4lt 0.1.2 (2024-03-17)
---------------------------

Bugfixes:

* Fix use of sh4lt with C code
* Accept nullptr for log in C API for sh4lt_get_shmmax and sh4lt_get_shmmni

Improvement:

* Add doxygen install for Ubuntu CI
* Remove use of python distutils module
* Development version are not tagged during release

sh4lt 0.1.0 (2024-02-21)
---------------------------

Breaking Changes:

* Python: simplification of `copy_to_shm`
* Rename pysh4lt into sh4lt
* Follower uses shared pointers on logger, and Python ctor has now optional arguments
* Log is now a shared pointer for `Writer` and `Follower`. So in pysh4lt most Writer ctor args are optional

New features:

* Add `Writer.num_of_followers` and `Follower.is_connected`
* Pysh4lt: make group optional in shtype ctor
* Make Sh4lt compatible with Shmdata writer
* Add release scripts

Improvement:

* Use of `std::make_unique` instead of `new`
* More GIL in Python wrapper

Bug fixes:

* Fix dbg debian package
* Fix install from sources
* Fix header installation
* Fix Python not built by default
* Fix NEWS.md


sh4lt 0.0.2 (2024-02-07)
---------------------------

New Features:

* Add "literal" python wrapper with doc and tests, using pybind11
* Add timecode and tests
* Add shlinew and shflow tools
* Use Shtype for Sh4lt description
* Replace file path with label and group label

Documentation:

* Add README.md and basic doc

Initialization:

* Improve and modernise code
* Add CI
* Import and refactor Shmdata
